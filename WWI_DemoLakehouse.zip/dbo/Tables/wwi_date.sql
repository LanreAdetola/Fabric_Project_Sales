CREATE TABLE [dbo].[wwi_date] (

	[Date] date NULL, 
	[Day] int NULL, 
	[MonthName] varchar(8000) NULL, 
	[MonthNumber] int NULL, 
	[Quarter] int NULL, 
	[Year] int NULL
);


GO
ALTER TABLE [dbo].[wwi_date] ADD CONSTRAINT UQ_7128e840_fdb3_49da_8ed1_952b6eb32976 unique NONCLUSTERED ([Date]);