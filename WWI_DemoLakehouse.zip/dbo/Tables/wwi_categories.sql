CREATE TABLE [dbo].[wwi_categories] (

	[CategoryID] int NULL, 
	[CategoryName] varchar(8000) NULL, 
	[Description] varchar(8000) NULL, 
	[Picture] varchar(8000) NULL
);


GO
ALTER TABLE [dbo].[wwi_categories] ADD CONSTRAINT UQ_56e246a3_0c8c_4782_b9e6_3f69f5756a59 unique NONCLUSTERED ([CategoryID]);