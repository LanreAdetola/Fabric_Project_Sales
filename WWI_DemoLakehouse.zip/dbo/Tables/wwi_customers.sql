CREATE TABLE [dbo].[wwi_customers] (

	[CustomerID] varchar(8000) NULL, 
	[CompanyName] varchar(8000) NULL, 
	[ContactName] varchar(8000) NULL, 
	[ContactTitle] varchar(8000) NULL, 
	[Address] varchar(8000) NULL, 
	[City] varchar(8000) NULL, 
	[Country] varchar(8000) NULL
);


GO
ALTER TABLE [dbo].[wwi_customers] ADD CONSTRAINT UQ_d2a43898_0fc0_4be8_aa93_620b11c87d13 unique NONCLUSTERED ([CustomerID]);