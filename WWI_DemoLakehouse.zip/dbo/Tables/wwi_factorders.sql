CREATE TABLE [dbo].[wwi_factorders] (

	[OrderID] bigint NULL, 
	[CustomerID] varchar(8000) NULL, 
	[EmployeeID] bigint NULL, 
	[OrderDate] date NULL, 
	[RequiredDate] date NULL, 
	[ShippedDate] date NULL, 
	[ShipVia] bigint NULL, 
	[Freight] float NULL, 
	[ShipName] varchar(8000) NULL, 
	[ShipAddress] varchar(8000) NULL, 
	[Country] varchar(8000) NULL
);


GO
ALTER TABLE [dbo].[wwi_factorders] ADD CONSTRAINT FK_9ae2b4eb_db63_4830_a11a_d6d13c6e00a2 FOREIGN KEY ([OrderID]) REFERENCES [dbo].[www_orderdetails]([OrderID]);