CREATE TABLE [dbo].[wwi_products] (

	[ProductID] bigint NULL, 
	[ProductName] varchar(8000) NULL, 
	[SupplierID] bigint NULL, 
	[CategoryID] bigint NULL, 
	[QuantityPerUnit] varchar(8000) NULL, 
	[UnitPrice] float NULL, 
	[UnitsInStock] bigint NULL, 
	[UnitsOnOrder] bigint NULL, 
	[ReorderLevel] bigint NULL
);


GO
ALTER TABLE [dbo].[wwi_products] ADD CONSTRAINT UQ_1498d219_651a_4a47_91c0_95d9d3956041 unique NONCLUSTERED ([ProductID]);
GO
ALTER TABLE [dbo].[wwi_products] ADD CONSTRAINT FK_d34f0f9f_52e0_4a8b_bc8f_a39d84ada55c FOREIGN KEY ([UnitPrice]) REFERENCES [dbo].[www_orderdetails]([UnitPrice]);