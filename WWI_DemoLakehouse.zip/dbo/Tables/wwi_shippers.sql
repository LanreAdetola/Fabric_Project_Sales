CREATE TABLE [dbo].[wwi_shippers] (

	[ShipperID] int NULL, 
	[CompanyName] varchar(8000) NULL, 
	[Phone] varchar(8000) NULL
);