CREATE TABLE [dbo].[www_orderdetails] (

	[OrderID] bigint NULL, 
	[ProductID] bigint NULL, 
	[Quantity] bigint NULL, 
	[SalesAmount] decimal(19,4) NULL, 
	[UnitPrice] float NULL
);


GO
ALTER TABLE [dbo].[www_orderdetails] ADD CONSTRAINT UQ_98f24454_3c15_4d61_a6de_d317058c799d unique NONCLUSTERED ([OrderID]);
GO
ALTER TABLE [dbo].[www_orderdetails] ADD CONSTRAINT UQ_c8a9a0d9_9fe2_4b80_b91b_a7aeab352a14 unique NONCLUSTERED ([UnitPrice]);